﻿using jQueryCascader.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace jQueryCascader.Web
{
    /// <summary>
    /// Summary description for sampleWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService]
    public class sampleWebService : System.Web.Services.WebService
    {
        List<Continent> _continents = new List<Continent>() { 
                new Continent(){ ContinentId=1, ContinentName="Africa"},
                new Continent(){ ContinentId=2, ContinentName="America"},
                new Continent(){ ContinentId=3, ContinentName="Asia"},
                new Continent(){ ContinentId=4, ContinentName="Europe"}
            };

        List<Country> _countries = new List<Country>() { 
                new Country(){ CountryId =1, ContinentId=1, CountryName="Nigeria"},
                new Country(){ CountryId=2, ContinentId=2, CountryName="America"},
                new Country(){ CountryId=3, ContinentId=3, CountryName="China"},
                new Country(){ CountryId=4, ContinentId=4, CountryName="United Kindom"}
            };

        List<State> _states = new List<State>() { 
                new State(){  StateId =1, CountryId=1, StateName="Lagos"},
                new State(){ StateId=2, CountryId=1, StateName="Oyo"},
                new State(){ StateId=3,CountryId=2,  StateName="Washington"},
                new State(){ StateId=4,CountryId=2,  StateName="California"}
            };

        [WebMethod]
        public IEnumerable<Continent> Continents()
        {
            return _continents;
        }

        [WebMethod]
        public IEnumerable<Country> Countries(int continentId)
        {
            List<Country> countries = this._countries.Where(x => x.ContinentId == continentId).ToList();
            return countries;
        }

        [WebMethod]
        public IEnumerable<State> States(int countryId)
        {
            System.Threading.Thread.Sleep(2000); //simulate long running method to show busy text
            List<State> states = this._states.Where(x => x.CountryId == countryId).ToList();
            return states;
        }

    }
}
