﻿using jQueryCascader.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace jQueryCascader.WebAPI.Controllers
{
    public class StatesController : ApiController
    {
        List<State> _states = new List<State>() { 
                new State(){  StateId =1, CountryId=1, StateName="Lagos"},
                new State(){ StateId=2, CountryId=1, StateName="Oyo"},
                new State(){ StateId=3,CountryId=2,  StateName="Washington"},
                new State(){ StateId=4,CountryId=2,  StateName="California"}
            };

        //GET api/states/
        public IEnumerable<State> Get(int countryId)
        {
            System.Threading.Thread.Sleep(2000); //simulate long running method to show busy text
            return this._states.Where(x => x.CountryId == countryId);
        }

    }
}
