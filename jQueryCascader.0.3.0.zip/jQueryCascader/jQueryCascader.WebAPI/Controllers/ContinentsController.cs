﻿using jQueryCascader.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace jQueryCascader.WebAPI.Controllers
{
    public class ContinentsController : ApiController
    {

        List<Continent> _continents = new List<Continent>() { 
                new Continent(){ ContinentId=1, ContinentName="Africa"},
                new Continent(){ ContinentId=2, ContinentName="America"},
                new Continent(){ ContinentId=3, ContinentName="Asia"},
                new Continent(){ ContinentId=4, ContinentName="Europe"}
            };

        List<Country> _countries = new List<Country>() { 
                new Country(){ CountryId =1, ContinentId=1, CountryName="Nigeria"},
                new Country(){ CountryId=2, ContinentId=2, CountryName="America"},
                new Country(){ CountryId=3, ContinentId=3, CountryName="China"},
                new Country(){ CountryId=4, ContinentId=4, CountryName="United Kindom"}
            };

        List<State> _states = new List<State>() { 
                new State(){  StateId =1, CountryId=1, StateName="Lagos"},
                new State(){ StateId=2, CountryId=1, StateName="Oyo"},
                new State(){ StateId=3,CountryId=2,  StateName="Washington"},
                new State(){ StateId=4,CountryId=2,  StateName="California"}
            };

        //GET api/continents/
        public IEnumerable<Continent> Get()
        {
            return this._continents;
        }

    }
}
