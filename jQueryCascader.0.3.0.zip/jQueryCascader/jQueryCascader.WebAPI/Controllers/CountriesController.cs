﻿using jQueryCascader.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace jQueryCascader.WebAPI.Controllers
{
    public class CountriesController : ApiController
    {
        List<Country> _countries = new List<Country>() { 
                new Country(){ CountryId =1, ContinentId=1, CountryName="Nigeria"},
                new Country(){ CountryId=2, ContinentId=2, CountryName="America"},
                new Country(){ CountryId=3, ContinentId=3, CountryName="China"},
                new Country(){ CountryId=4, ContinentId=4, CountryName="United Kindom"}
            };

        //GET api/countries/
        public IEnumerable<Country> Get(int continentId)
        {
            return this._countries.Where(x => x.ContinentId == continentId);
        }

    }
}
