﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jQueryCascader.MVC.Models
{
    public class Country
    {
        public int CountryId { get; set; }
        public int ContinentId { get; set; }
        public string CountryName { get; set; }
    }
}