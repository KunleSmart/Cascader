(function ($) {
    $.fn.cascader = function (options) {
        var opts = $.extend({
        }, $.fn.cascader.defaults, options);
        var _cascader = new Byaxiom.Cascader(opts.value, opts.text, opts.parameters, opts.parentControlIds, opts.defaultValue, opts.defaultText, opts.omitValues, opts.omitIfTextEmpty, opts.busyText, opts.method, opts.onChange);
        _cascader.subscribe($(this));
    };
    $.fn.cascader.defaults = {
        value: "Id",
        text: "Name",
        parameters: null,
        parentControlIds: null,
        defaultValue: "0",
        defaultText: "--select--",
        omitValues: "0",
        omitIfTextEmpty: true,
        busyText: "loading...",
        method: null,
        onChange: null
    };
})(jQuery);
var Byaxiom;
(function (Byaxiom) {
    var Cascader = (function () {
        function Cascader(value, text, parameters, parentControlIds, defaultValue, defaultText, omitValues, omitIfTextEmpty, busyText, method, onChange) {
            this.value = value;
            this.text = text;
            this.parentControlIds = parentControlIds;
            this.defaultValue = defaultValue;
            this.defaultText = defaultText;
            this.omitValues = omitValues;
            this.omitIfTextEmpty = omitIfTextEmpty;
            this.busyText = busyText;
            this.method = method;
            this.parameters = parameters;
            this.onChange = onChange;
        }
        Cascader.prototype.subscribe = function (control) {
            this.control = control;
            this.controlId = control.attr("Id");
            this.container = $("span#cnt" + this.controlId);
            var $this = this;
            if(this.parentControlIds != null) {
                for(var i = 0; i < this.parentControlIds.length; i++) {
                    var parent = $("#" + this.parentControlIds[i]);
                    if(typeof parent !== "undefined") {
                        parent.change(function () {
                            $this.loadData($this);
                        });
                        return;
                    }
                }
            }
            $this.loadData($this);
        };
        Cascader.prototype.enableControl = function (val) {
            if(val === true) {
                this.control.attr("disabled", false);
                this.container.css("display", "none");
            } else {
                this.control.attr("disabled", "disabled");
                this.container.css("display", "");
            }
        };
        Cascader.prototype.refreshDdl = function () {
            try  {
                $("select option").each(function () {
                    this.attr('title', this.html());
                    return false;
                });
            } catch (e) {
                alert;
            }
        };
        Cascader.getBaseURL = function getBaseURL() {
            var url = location.href;
            var pathname = location.pathname;
            url = url.replace("\\", "/");
            if(url.substr(url.length - 1, 1) != "/") {
                url += "/";
            }
            var baseURL = url.substring(0, url.indexOf('/', 14));
            var isSecondLevel = false;
            if(baseURL.indexOf("www.") != -1) {
                isSecondLevel = false;
            } else {
                if(baseURL.indexOf("http://localhost:") != -1) {
                    isSecondLevel = false;
                } else {
                    isSecondLevel = true;
                }
            }
            if(isSecondLevel) {
                var index1 = url.indexOf(pathname);
                var index2 = url.indexOf("/", index1 + 1);
                var baseLocalUrl = url.substr(0, index2);
                return baseLocalUrl + "/";
            } else {
                return baseURL + "/";
            }
        }
        Cascader.prototype.loadData = function ($this) {
            if($this.container.size() > 0) {
                this.container.css("display", "");
            } else {
                $this.container = $('<span/>').attr('id', "cnt" + this.controlId).css("margin-left", "5px").html(this.busyText);
                $this.control.after(this.container);
            }
            var params = "";
            var asmxParams = "";
            if($this.parameters != null && $this.parentControlIds != null) {
                if($this.parameters.length === $this.parentControlIds.length) {
                    for(var i = 0; i < $this.parentControlIds.length; i++) {
                        if(params.length > 0) {
                            params += "&";
                        }
                        params += $this.parameters[i] + "=" + $("#" + $this.parentControlIds[i]).val();
                        if(asmxParams.length > 0) {
                            asmxParams += "";
                        }
                        asmxParams += "'" + $this.parameters[i] + "':'" + $("#" + $this.parentControlIds[i]).val() + "'";
                    }
                }
            }
            var currentValue = $this.control.val();
            var address = $this.method;
            var isASMX = false;
            if(address.indexOf(".asmx") > -1) {
                isASMX = true;
            }
            if(isASMX == false) {
                address += (params.length > 0 ? "?" + params : "");
            }
            if(address.indexOf("http://") == -1) {
                var base = Byaxiom.Cascader.getBaseURL();
                if(base != "/") {
                    address = base + address;
                }
            }
            asmxParams = "{" + asmxParams + "}";
            var _type = "GET";
            var _data = "";
            if(isASMX) {
                _type = "POST";
                _data = asmxParams;
            }
            $.ajax({
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                type: _type,
                data: _data,
                cache: false,
                url: address,
                error: function (response) {
                    $this.enableControl(true);
                },
                success: function (response) {
                    $this.processData($this, response, currentValue);
                }
            });
        };
        Cascader.prototype.processData = function ($this, response, currentValue) {
            $this.enableControl(true);
            $("select[id='" + $this.controlId + "'] option").remove();
            $("<option value=" + $this.defaultValue + ">" + $this.defaultText + "</option>").appendTo($this.control);
            if(typeof response.d !== "undefined") {
                response = response.d;
            }
            if(typeof response !== "object") {
                $this.container.css("display", "none");
                return;
            }
            var _omitValues = $this.omitValues.split(",");
            var isToContinue = false;
            var txt;
            var val;
            var currentValueFound = false;
            for(var i = 0; i < response.length; i++) {
                isToContinue = false;
                for(var j = 0; j < _omitValues.length; j++) {
                    if(_omitValues[j] === $.attr(response[i], $this.value)) {
                        isToContinue = true;
                        break;
                    }
                }
                txt = $.trim($.attr(response[i], $this.text));
                val = $.trim($.attr(response[i], $this.value));
                if($this.omitIfTextEmpty) {
                    if(txt.length === 0) {
                        isToContinue = true;
                    }
                }
                if(!isToContinue) {
                    if(currentValue === val) {
                        currentValueFound = true;
                    }
                    $("<option value=" + val + ">" + txt + "</option>").appendTo($this.control);
                }
            }
            if(currentValueFound === true) {
                $this.control.val(currentValue);
            } else {
                $this.control.val($this.defaultValue);
            }
            $this.container.css("display", "none");
            $this.refreshDdl();
            if($this.onChange !== null) {
                $this.control.change(function () {
                    $this.onChange();
                });
            }
            $this.control.trigger("change");
        };
        return Cascader;
    })();
    Byaxiom.Cascader = Cascader;    
})(Byaxiom || (Byaxiom = {}));
