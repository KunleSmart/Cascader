/*
    Static members of jQuery (those on $ and jQuery themselves)
*/
interface JQueryStatic {
    ajax(settings: JQueryAjaxSettings);
    modal: SimpleModal;
    busy();
    validator: JQueryValidate;
    attr(object: any, val: string);
    concurrency(settings: ConcurrencySettings);
    message(header: string, message: string, isModal?: bool);
}

/*
    The jQuery instance members
*/
interface JQuery {
    size(): number;
    draggable(handle);
    valid();
    ajaxify(settings: any);
    cascader(settings: any);
    fineUploader(settings: any);
    fineUploader(acion: string, settings: any);
    button();
    datepicker(settings: any);
    validate(settings: any);
    modal(settings: any);
    autopager(settings: any);
}

interface JQueryValidate {
    unobtrusive: any;
}

//Others start from here
interface ConcurrencySettings {
    type: string;
    onComplete: any;
}

class SimpleModal {
    update();
    close();
}

class AjaxUpload {
    constructor (value: string, setting: any);
}

class ModenizrStatic {
    inputtypes: any;
}

declare var jQuery: JQueryStatic;
declare var $: JQueryStatic;
declare var Modenizr: ModenizrStatic;
declare var sitePath;